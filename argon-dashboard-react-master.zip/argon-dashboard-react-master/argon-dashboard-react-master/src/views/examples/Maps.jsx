
import React from "react";
// react plugin used to create google maps

// core components
import Header from "components/Headers/Header.jsx";

class Maps extends React.Component {
  render() {
    return (
      <>
        <Header />
        {/* Page content */}
       
      </>
    );
  }
}



// <div>
//   {
//     this.state.value === 2 ? getImageFor2() : null
//   }
//   {
//     this.state.value === 4 ? getImageFor4() : null
//   }
// </div>

export default Maps;
