
import React from "react";
// react plugin used to create google maps


// reactstrap components
import { Card, Container, Row } from "reactstrap";

// core components
import Header from "components/Headers/Header.jsx";
// mapTypeId={google.maps.MapTypeId.ROADMAP}


class Notifications extends React.Component {
  render() {
    return (
      <>
        <Header />
  
       
      </>
    );
  }
}

export default Notifications;
